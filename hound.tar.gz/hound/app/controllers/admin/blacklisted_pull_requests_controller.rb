module Admin
  class BlacklistedPullRequestsController < Admin::ApplicationController
  end
end
