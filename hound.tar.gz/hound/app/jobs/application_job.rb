class ApplicationJob
  include Sidekiq::Worker
end
